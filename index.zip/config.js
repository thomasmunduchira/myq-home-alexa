const config = {
  appId: 'amzn1.ask.skill.9e229737-4034-44b0-a9e5-db349350397c',
  db: {
    name: 'myq-home',
  },
  requestTimeout: 2250,
  endpoint: 'https://myq.thomasmunduchira.com',
};

module.exports = config;
